alert("Welcome to the Interactive JS Page!");

function processInput() {
  // Get values from inputs
  const name = document.getElementById('name').value.trim();
  const age = parseInt(document.getElementById('age').value.trim());

  // Greeting
  let greeting = `Hello, ${name || "friend"}!`;

  // Average weeks left (assuming 80 years lifespan)
  const lifespan = 80;
  const weeksInAYear = 52;
  const weeksLived = age * weeksInAYear;
  const weeksRemaining = (lifespan - age) * weeksInAYear;

  // Time of day greeting
  const hour = new Date().getHours();
  let timeGreeting;
  if (hour >= 5 && hour < 12) {
    timeGreeting = "Good morning!";
  } else if (hour >= 12 && hour < 18) {
    timeGreeting = "Good afternoon!";
  } else {
    timeGreeting = "Good evening!";
  }

  // Output everything
  const output = `
    ${greeting}<br>
    ${timeGreeting}<br>
    You've lived approximately <strong>${weeksLived}</strong> weeks.<br>
    You have approximately <strong>${weeksRemaining}</strong> weeks remaining (if you live to ${lifespan}).`;

  document.getElementById('output').innerHTML = output;
}
