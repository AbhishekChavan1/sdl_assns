
require 'sinatra'

set :bind, '0.0.0.0'
set :port, 5000

get '/' do
  erb :index
end

post '/reverse' do
  @first_name = params[:first_name]
  @last_name = params[:last_name]
  @reversed_name = "#{@last_name} #{@first_name}"
  erb :reverse
end
