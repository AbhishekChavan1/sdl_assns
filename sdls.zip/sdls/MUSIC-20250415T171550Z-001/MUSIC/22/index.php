<?php
// Indexed array of 20 employee names
$employee_names = [
    "John Doe", "Jane Smith", "Peter Brown", "Lucy Green", "Mark White",
    "Sarah Black", "Paul Blue", "Nina Red", "Tom Yellow", "Lily Grey",
    "Jack Purple", "Anna Orange", "David Violet", "Eva Pink", "Mia Indigo",
    "Ethan Gold", "Chloe Silver", "Olivia Bronze", "Sophia Platinum", "James Copper"
];

// Function to search for an employee name in the array
function searchEmployee($name, $array) {
    if (in_array($name, $array)) {
        return true;
    } else {
        return false;
    }
}

// Variable to store the search result
$found = false;
$search_name = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the input from the user
    $search_name = trim($_POST['employee_name']);
    $found = searchEmployee($search_name, $employee_names);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Array Search Example</title>
</head>
<body>
    <h1>PHP Array Search Example</h1>

    <h2>Search for an Employee:</h2>
    <!-- HTML Form to take user input -->
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="employee_name">Enter Employee Name: </label>
        <input type="text" id="employee_name" name="employee_name" required>
        <button type="submit">Search</button>
    </form>

    <h2>Employee Names List:</h2>
    <ul>
        <?php
        // Displaying the list of employee names
        foreach ($employee_names as $name) {
            echo "<li>$name</li>";
        }
        ?>
    </ul>

    <h2>Search Result:</h2>
    <p>
        <?php
        if ($search_name !== "" && $found) {
            echo "The employee '$search_name' was found in the list.";
        } elseif ($search_name !== "") {
            echo "The employee '$search_name' was not found in the list.";
        }
        ?>
    </p>

</body>
</html>
