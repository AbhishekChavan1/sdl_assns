<?php
include('db.php');

// Fetch all complaints
$stmt = $pdo->query("SELECT * FROM complaints ORDER BY created_at DESC");
$complaints = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaints List</title>
</head>
<body>
    <h1>List of Complaints</h1>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Complaint</th>
                <th>Status</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($complaints as $complaint): ?>
                <tr>
                    <td><?= $complaint['id'] ?></td>
                    <td><?= $complaint['name'] ?></td>
                    <td><?= $complaint['email'] ?></td>
                    <td><?= $complaint['complaint_text'] ?></td>
                    <td><?= $complaint['status'] ?></td>
                    <td><?= $complaint['created_at'] ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
