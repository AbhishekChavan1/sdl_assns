<?php
include('db.php');

// Handle complaint submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $complaint_text = $_POST['complaint_text'];

    // Insert complaint into the database
    $stmt = $pdo->prepare("INSERT INTO complaints (name, email, complaint_text) VALUES (?, ?, ?)");
    $stmt->execute([$name, $email, $complaint_text]);

    echo "Complaint submitted successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Complaint</title>
</head>
<body>
    <h1>Submit a Complaint</h1>
    <form action="submit_complaint.php" method="POST">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" required><br><br>

        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="complaint_text">Complaint:</label><br>
        <textarea id="complaint_text" name="complaint_text" required></textarea><br><br>

        <input type="submit" value="Submit Complaint">
    </form>
</body>
</html>
