<?php
include('db.php');

// Handle complaint status update
if (isset($_POST['update_status'])) {
    $status = $_POST['status'];
    $complaint_id = $_POST['complaint_id'];

    $stmt = $pdo->prepare("UPDATE complaints SET status = ? WHERE id = ?");
    $stmt->execute([$status, $complaint_id]);

    echo "Complaint status updated!";
}

// Fetch all complaints
$stmt = $pdo->query("SELECT * FROM complaints ORDER BY created_at DESC");
$complaints = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Complaints</title>
</head>
<body>
    <h1>Manage Complaints</h1>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Complaint</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($complaints as $complaint): ?>
                <tr>
                    <td><?= $complaint['id'] ?></td>
                    <td><?= $complaint['name'] ?></td>
                    <td><?= $complaint['email'] ?></td>
                    <td><?= $complaint['complaint_text'] ?></td>
                    <td><?= $complaint['status'] ?></td>
                    <td>
                        <form action="manage_complaints.php" method="POST">
                            <input type="hidden" name="complaint_id" value="<?= $complaint['id'] ?>">
                            <select name="status">
                                <option value="Pending" <?= $complaint['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
                                <option value="Resolved" <?= $complaint['status'] == 'Resolved' ? 'selected' : '' ?>>Resolved</option>
                                <option value="Closed" <?= $complaint['status'] == 'Closed' ? 'selected' : '' ?>>Closed</option>
                            </select>
                            <button type="submit" name="update_status">Update Status</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
