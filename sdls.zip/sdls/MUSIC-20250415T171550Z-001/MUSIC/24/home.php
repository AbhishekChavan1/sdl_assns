<?php
include 'db.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION["user_id"];
$username = $_SESSION["username"];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Facebook Clone - Home</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<h2>Welcome, <?= $username ?>!</h2>
<a href="logout.php">Logout</a>

<h3>Create a Post</h3>
<form method="post" action="post.php">
    <textarea name="content" required placeholder="What's on your mind?"></textarea><br>
    <button type="submit">Post</button>
</form>

<h3>News Feed</h3>
<?php
$posts = $conn->query("SELECT p.content, p.created_at, u.username 
                       FROM posts p JOIN users u ON p.user_id = u.id 
                       ORDER BY p.created_at DESC");

while ($row = $posts->fetch_assoc()) {
    echo "<div class='post'><strong>{$row['username']}</strong><br>{$row['content']}<br><small>{$row['created_at']}</small></div>";
}
?>
</body>
</html>
