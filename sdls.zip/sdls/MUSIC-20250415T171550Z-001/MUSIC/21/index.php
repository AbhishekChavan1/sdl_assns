<?php
// Parent Class
class Animal {
    // Property
    public $name;

    // Constructor
    public function __construct($name) {
        $this->name = $name;
    }

    // Method
    public function speak() {
        return $this->name . " makes a sound.";
    }
}

// Child Class that inherits from Animal
class Dog extends Animal {
    // Method overriding
    public function speak() {
        return $this->name . " barks!";
    }

    // Additional Method
    public function fetch() {
        return $this->name . " is fetching the ball!";
    }
}

// Creating an object of the Animal class
$animal = new Animal("Generic Animal");

// Creating an object of the Dog class
$dog = new Dog("Buddy");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Inheritance Example</title>
</head>
<body>
    <h1>PHP Inheritance Example</h1>

    <h2>Animal Object</h2>
    <p><?php echo $animal->speak(); ?></p>  <!-- Inherited method from Animal class -->

    <h2>Dog Object (Child Class)</h2>
    <p><?php echo $dog->speak(); ?></p>  <!-- Overridden method in Dog class -->
    <p><?php echo $dog->fetch(); ?></p>  <!-- Additional method in Dog class -->

</body>
</html>
