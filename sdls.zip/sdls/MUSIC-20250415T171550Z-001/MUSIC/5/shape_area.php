<!DOCTYPE html>
<html>
<head>
  <title>Shape Area Calculator (No JS)</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f0f0f0;
      padding: 40px;
    }
    .container {
      background: #fff;
      padding: 25px;
      max-width: 500px;
      margin: auto;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    h2 {
      text-align: center;
      color: #333;
    }
    .form-group {
      margin: 15px 0;
    }
    label {
      font-weight: bold;
    }
    input[type="number"], input[type="submit"] {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    .result {
      background: #e6ffe6;
      padding: 10px;
      border: 1px solid #b2d8b2;
      margin-top: 20px;
      border-radius: 5px;
    }
  </style>
</head>
<body>

<?php
// Base class
class Shape {
  public $dim1, $dim2;
  function __construct($d1, $d2 = 0) {
    $this->dim1 = $d1;
    $this->dim2 = $d2;
  }
  function area() {
    return 0;
  }
}

class Triangle extends Shape {
  function area() {
    return 0.5 * $this->dim1 * $this->dim2;
  }
}

class Square extends Shape {
  function area() {
    return $this->dim1 * $this->dim1;
  }
}

class Circle extends Shape {
  function area() {
    return 3.1416 * $this->dim1 * $this->dim1;
  }
}

$shapeType = $_POST['shape'] ?? '';
$dim1 = $_POST['dim1'] ?? '';
$dim2 = $_POST['dim2'] ?? '';
$result = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
  $d1 = floatval($dim1);
  $d2 = floatval($dim2);

  switch ($shapeType) {
    case 'triangle':
      $shape = new Triangle($d1, $d2);
      break;
    case 'square':
      $shape = new Square($d1);
      break;
    case 'circle':
      $shape = new Circle($d1);
      break;
    default:
      $shape = null;
  }

  if ($shape) {
    $result = "Area of the <strong>$shapeType</strong> is <strong>" . $shape->area() . "</strong>";
  }
}
?>

<div class="container">
  <h2>Shape Area Calculator</h2>

  <form method="post">
    <div class="form-group">
      <label>Select Shape:</label><br>
      <input type="radio" name="shape" value="triangle" <?= $shapeType == 'triangle' ? 'checked' : '' ?>> Triangle<br>
      <input type="radio" name="shape" value="square" <?= $shapeType == 'square' ? 'checked' : '' ?>> Square<br>
      <input type="radio" name="shape" value="circle" <?= $shapeType == 'circle' ? 'checked' : '' ?>> Circle
    </div>

    <?php if ($shapeType): ?>
      <div class="form-group">
        <label>
          <?= ($shapeType == 'circle') ? 'Radius' : (($shapeType == 'square') ? 'Side' : 'Base') ?>
        </label>
        <input type="number" name="dim1" step="0.01" value="<?= htmlspecialchars($dim1) ?>" required>
      </div>

      <?php if ($shapeType == 'triangle'): ?>
        <div class="form-group">
          <label>Height</label>
          <input type="number" name="dim2" step="0.01" value="<?= htmlspecialchars($dim2) ?>" required>
        </div>
      <?php endif; ?>
    <?php endif; ?>

    <input type="submit" name="submit" value="Calculate Area">
  </form>

  <?php if ($result): ?>
    <div class="result"><?= $result ?></div>
  <?php endif; ?>
</div>

</body>
</html>
