<?php include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $brand = $_POST['brand'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $expiry = $_POST['expiry'];

    $stmt = $pdo->prepare("INSERT INTO medicines (name, brand, price, quantity, expiry_date) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $brand, $price, $quantity, $expiry]);

    echo "Medicine added successfully!";
}
?>

<form method="POST">
    Name: <input name="name" required><br>
    Brand: <input name="brand"><br>
    Price: <input type="number" step="0.01" name="price" required><br>
    Quantity: <input type="number" name="quantity" required><br>
    Expiry Date: <input type="date" name="expiry"><br>
    <input type="submit" value="Add Medicine">
</form>
