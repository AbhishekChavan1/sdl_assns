<?php include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['medicine_id'];
    $qty = $_POST['quantity'];

    $stmt = $pdo->prepare("SELECT price, quantity FROM medicines WHERE id = ?");
    $stmt->execute([$id]);
    $medicine = $stmt->fetch();

    if ($medicine && $medicine['quantity'] >= $qty) {
        $total = $medicine['price'] * $qty;

        // Update stock
        $pdo->prepare("UPDATE medicines SET quantity = quantity - ? WHERE id = ?")->execute([$qty, $id]);

        // Record sale
        $pdo->prepare("INSERT INTO sales (medicine_id, quantity_sold, total_price) VALUES (?, ?, ?)")
            ->execute([$id, $qty, $total]);

        echo "Sale recorded. Total: $" . number_format($total, 2);
    } else {
        echo "Insufficient stock.";
    }
}
?>

<form method="POST">
    Medicine ID: <input type="number" name="medicine_id" required><br>
    Quantity: <input type="number" name="quantity" required><br>
    <input type="submit" value="Sell">
</form>
