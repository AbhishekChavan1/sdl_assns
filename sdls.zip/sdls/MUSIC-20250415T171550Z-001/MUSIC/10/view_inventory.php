<?php include('db.php');

$meds = $pdo->query("SELECT * FROM medicines")->fetchAll();
?>

<h2>Inventory</h2>
<table border="1">
    <tr>
        <th>ID</th><th>Name</th><th>Brand</th><th>Price</th><th>Quantity</th><th>Expiry</th>
    </tr>
    <?php foreach ($meds as $med): ?>
        <tr>
            <td><?= $med['id'] ?></td>
            <td><?= $med['name'] ?></td>
            <td><?= $med['brand'] ?></td>
            <td><?= $med['price'] ?></td>
            <td><?= $med['quantity'] ?></td>
            <td><?= $med['expiry_date'] ?></td>
        </tr>
    <?php endforeach; ?>
</table>
