<?php include('db.php');

$sales = $pdo->query("SELECT s.id, m.name, s.quantity_sold, s.total_price, s.sale_date 
                      FROM sales s 
                      JOIN medicines m ON s.medicine_id = m.id")->fetchAll();
?>

<h2>Sales History</h2>
<table border="1">
    <tr>
        <th>ID</th><th>Medicine</th><th>Quantity</th><th>Total</th><th>Date</th>
    </tr>
    <?php foreach ($sales as $sale): ?>
        <tr>
            <td><?= $sale['id'] ?></td>
            <td><?= $sale['name'] ?></td>
            <td><?= $sale['quantity_sold'] ?></td>
            <td>$<?= $sale['total_price'] ?></td>
            <td><?= $sale['sale_date'] ?></td>
        </tr>
    <?php endforeach; ?>
</table>
