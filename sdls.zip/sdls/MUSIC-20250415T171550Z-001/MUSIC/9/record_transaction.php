<?php
include('db.php');

// Handle transaction recording
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $vehicle_id = $_POST['vehicle_id'];
    $toll_fee_id = $_POST['toll_fee_id'];
    $amount_paid = $_POST['amount_paid'];

    $stmt = $pdo->prepare("INSERT INTO transactions (vehicle_id, toll_fee_id, amount_paid) VALUES (?, ?, ?)");
    $stmt->execute([$vehicle_id, $toll_fee_id, $amount_paid]);

    echo "Transaction recorded successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Transaction</title>
</head>
<body>
    <h1>Record Toll Transaction</h1>
    <form action="record_transaction.php" method="POST">
        <label for="vehicle_id">Vehicle ID:</label><br>
        <input type="number" id="vehicle_id" name="vehicle_id" required><br><br>

        <label for="toll_fee_id">Toll Fee ID:</label><br>
        <input type="number" id="toll_fee_id" name="toll_fee_id" required><br><br>

        <label for="amount_paid">Amount Paid:</label><br>
        <input type="text" id="amount_paid" name="amount_paid" required><br><br>

        <input type="submit" value="Record Transaction">
    </form>
</body>
</html>
