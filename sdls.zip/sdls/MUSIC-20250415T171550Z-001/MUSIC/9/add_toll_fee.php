<?php
include('db.php');

// Handle toll fee addition
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $vehicle_type = $_POST['vehicle_type'];
    $fee = $_POST['fee'];

    $stmt = $pdo->prepare("INSERT INTO toll_fees (vehicle_type, fee) VALUES (?, ?)");
    $stmt->execute([$vehicle_type, $fee]);

    echo "Toll fee added successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Toll Fee</title>
</head>
<body>
    <h1>Add Toll Fee</h1>
    <form action="add_toll_fee.php" method="POST">
        <label for="vehicle_type">Vehicle Type:</label><br>
        <select name="vehicle_type" id="vehicle_type" required>
            <option value="Car">Car</option>
            <option value="Truck">Truck</option>
            <option value="Bus">Bus</option>
            <option value="Motorcycle">Motorcycle</option>
        </select><br><br>

        <label for="fee">Fee Amount:</label><br>
        <input type="text" id="fee" name="fee" required><br><br>

        <input type="submit" value="Add Toll Fee">
    </form>
</body>
</html>
