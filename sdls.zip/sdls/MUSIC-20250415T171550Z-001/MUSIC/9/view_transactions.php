<?php
include('db.php');

// Fetch transaction history
$stmt = $pdo->query("SELECT t.id, v.vehicle_number, tf.vehicle_type, t.amount_paid, t.transaction_time FROM transactions t
    JOIN vehicles v ON t.vehicle_id = v.id
    JOIN toll_fees tf ON t.toll_fee_id = tf.id");
$transactions = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction History</title>
</head>
<body>
    <h1>Transaction History</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Transaction ID</th>
                <th>Vehicle Number</th>
                <th>Vehicle Type</th>
                <th>Amount Paid</th>
                <th>Transaction Time</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($transactions as $transaction): ?>
                <tr>
                    <td><?= $transaction['id'] ?></td>
                    <td><?= $transaction['vehicle_number'] ?></td>
                    <td><?= $transaction['vehicle_type'] ?></td>
                    <td><?= $transaction['amount_paid'] ?></td>
                    <td><?= $transaction['transaction_time'] ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
