<?php
include('db.php');

// Handle vehicle registration
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $vehicle_number = $_POST['vehicle_number'];
    $vehicle_type = $_POST['vehicle_type'];
    $owner_name = $_POST['owner_name'];
    $owner_contact = $_POST['owner_contact'];

    $stmt = $pdo->prepare("INSERT INTO vehicles (vehicle_number, vehicle_type, owner_name, owner_contact) VALUES (?, ?, ?, ?)");
    $stmt->execute([$vehicle_number, $vehicle_type, $owner_name, $owner_contact]);

    echo "Vehicle registered successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Vehicle</title>
</head>
<body>
    <h1>Register a Vehicle</h1>
    <form action="register_vehicle.php" method="POST">
        <label for="vehicle_number">Vehicle Number:</label><br>
        <input type="text" id="vehicle_number" name="vehicle_number" required><br><br>

        <label for="vehicle_type">Vehicle Type:</label><br>
        <select name="vehicle_type" id="vehicle_type" required>
            <option value="Car">Car</option>
            <option value="Truck">Truck</option>
            <option value="Bus">Bus</option>
            <option value="Motorcycle">Motorcycle</option>
        </select><br><br>

        <label for="owner_name">Owner's Name:</label><br>
        <input type="text" id="owner_name" name="owner_name" required><br><br>

        <label for="owner_contact">Owner's Contact:</label><br>
        <input type="text" id="owner_contact" name="owner_contact" required><br><br>

        <input type="submit" value="Register Vehicle">
    </form>
</body>
</html>
