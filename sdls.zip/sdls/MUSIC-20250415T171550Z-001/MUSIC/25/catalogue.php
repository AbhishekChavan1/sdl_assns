<?php include 'db.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Books Catalogue</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 30px;
        }
        .catalogue {
            background: white;
            padding: 20px;
            border-radius: 10px;
            width: 700px;
            margin: auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .book {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }
        .book:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <div class="catalogue">
        <h2>📚 Books Catalogue</h2>
        <?php
        $sql = "SELECT * FROM books";
        $result = $conn->query($sql);

        if ($result->num_rows > 0):
            while ($book = $result->fetch_assoc()):
        ?>
            <div class="book">
                <h3><?= htmlspecialchars($book['title']) ?></h3>
                <p><strong>Author:</strong> <?= htmlspecialchars($book['author']) ?></p>
                <p><strong>Genre:</strong> <?= htmlspecialchars($book['genre']) ?> | <strong>Year:</strong> <?= $book['year'] ?></p>
            </div>
        <?php
            endwhile;
        else:
            echo "<p>No books found.</p>";
        endif;
        ?>
    </div>
</body>
</html>
