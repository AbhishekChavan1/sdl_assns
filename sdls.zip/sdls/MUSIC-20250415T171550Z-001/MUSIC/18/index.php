<?php
// Step 1: Check if the cookies are set and display them
if (isset($_COOKIE["user"])) {
    echo "Hello, " . $_COOKIE["user"] . "<br>"; // Outputs: Hello, John Doe
} else {
    echo "Cookie 'user' is not set!<br>"; // This will show on the first request
}

if (isset($_COOKIE["theme"])) {
    echo "Theme: " . $_COOKIE["theme"] . "<br>"; // Outputs: Theme: dark
}

if (isset($_COOKIE["language"])) {
    echo "Preferred Language: " . $_COOKIE["language"] . "<br>"; // Outputs: Preferred Language: English
}

// Step 2: Set cookies (this will be effective in the next request)
if (!isset($_COOKIE["user"])) {
    // Setting cookies only if they are not already set
    setcookie("user", "John Doe", time() + 3600, "/"); // expires in 1 hour
    setcookie("theme", "dark", time() + (7 * 24 * 60 * 60), "/"); // expires in 7 days
    setcookie("language", "English", time() + 3600, "/"); // expires in 1 hour

    // Redirect to the same page to check the cookies in the next request
    header("Location: " . $_SERVER['PHP_SELF']);
    exit(); // Stop the script from executing after the redirect
}
?>
