<!DOCTYPE html>
<html>
<head>
    <title>PHP Array Sort and Sum</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
        }
        input, button {
            padding: 10px;
            font-size: 16px;
        }
        .output {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<h2>Enter Numbers Separated by Commas (,)</h2>

<form method="post">
    <input type="text" name="numbers" placeholder="e.g. 10, 5, 20, 3" size="40">
    <button type="submit">Submit</button>
</form>

<div class="output">
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $input = $_POST["numbers"];
    
    // Convert input string to array
    $numbers = explode(",", $input);
    $clean_numbers = [];

    // Clean and convert to integers
    foreach ($numbers as $num) {
        $trimmed = trim($num);
        if (is_numeric($trimmed)) {
            $clean_numbers[] = (int)$trimmed;
        }
    }

    if (count($clean_numbers) > 0) {
        sort($clean_numbers); // Sort the array
        $sum = array_sum($clean_numbers); // Sum

        echo "<p><strong>Sorted Numbers:</strong> " . implode(", ", $clean_numbers) . "</p>";
        echo "<p><strong>Sum of Numbers:</strong> $sum</p>";
    } else {
        echo "<p style='color:red;'>Please enter valid numbers.</p>";
    }
}
?>
</div>

</body>
</html>
