<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $token = bin2hex(random_bytes(16));

    // Save to DB
    $stmt = $conn->prepare("INSERT INTO users (email, password, token) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $email, $password, $token);
    $stmt->execute();

    // Generate verification link
    $verifyLink = "http://localhost/sdl/26/verify.php?token=$token";

    echo "<h2>Registration successful!</h2>";
    echo "Click the link to verify your email: <a href='$verifyLink'>$verifyLink</a>";
}
?>

<form method="post">
    <input type="email" name="email" placeholder="Enter Email" required><br><br>
    <input type="password" name="password" placeholder="Enter Password" required><br><br>
    <button type="submit">Register</button>
</form>
