<!DOCTYPE html>
<html>
<head><title>Welcome</title></head>
<body>
<h2>Welcome to Your Dashboard!</h2>
<p>You have successfully verified your email.</p>
</body>
</html>
