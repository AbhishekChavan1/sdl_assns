<?php
include 'db.php';

if (isset($_GET['token']) && !empty($_GET['token'])) {
    $token = $_GET['token'];

    $stmt = $conn->prepare("SELECT id FROM users WHERE token = ? AND is_verified = 0");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        // Mark as verified
        $update = $conn->prepare("UPDATE users SET is_verified = 1 WHERE token = ?");
        $update->bind_param("s", $token);
        $update->execute();

        echo "<h2>Email verified successfully!</h2>";
        echo "<a href='success.php'>Go to Dashboard</a>";
    } else {
        echo "<h2>Invalid or already verified token.</h2>";
    }
} else {
    echo "<h2>No token provided. Please check your verification link.</h2>";
}
?>
