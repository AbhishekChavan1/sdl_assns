// Show an alert when the page loads
window.onload = function() {
    alert("Welcome to the JavaScript example!");

    // Call functions to display content
    displayAverageWeeks();
    displayTimeOfDay();
    displayStringVariable();
};

// Calculate the average number of weeks in a human lifetime
function displayAverageWeeks() {
    const averageLifeExpectancy = 72; // Average life expectancy in years
    const weeksInYear = 52;
    const averageWeeks = averageLifeExpectancy * weeksInYear;
    document.getElementById('average-weeks').textContent = `Average number of weeks in a human lifetime: ${averageWeeks} weeks.`;
}

// Program to tell the time of day
function displayTimeOfDay() {
    const currentHour = new Date().getHours();
    let timeOfDay = '';

    if (currentHour >= 5 && currentHour < 12) {
        timeOfDay = 'morning';
    } else if (currentHour >= 12 && currentHour < 18) {
        timeOfDay = 'afternoon';
    } else {
        timeOfDay = 'night';
    }

    document.getElementById('time-of-day').textContent = `It's currently the ${timeOfDay}.`;
}

// Create a variable to store a string and display it
function displayStringVariable() {
    const myString = 'This is a string variable!';
    document.getElementById('string-variable').textContent = myString;
}
