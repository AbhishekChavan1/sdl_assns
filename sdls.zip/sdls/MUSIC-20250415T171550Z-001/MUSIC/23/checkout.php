<?php
session_start();
$_SESSION['cart'] = []; // Clear cart
echo "<h2>Checkout Complete!</h2>";
echo "<a href='index.php'>Shop More</a>";
