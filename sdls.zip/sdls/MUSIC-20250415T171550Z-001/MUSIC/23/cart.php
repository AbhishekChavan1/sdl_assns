<?php
session_start();
include 'db.php';

$cart = $_SESSION['cart'] ?? [];
$total = 0;

echo "<h2>Your Cart</h2>";
echo '<a href="index.php">Back to Store</a> | <a href="checkout.php">Checkout</a><hr>';

if (!$cart) {
    echo "Cart is empty.";
    exit;
}

foreach ($cart as $id => $qty) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();

    $subtotal = $product['price'] * $qty;
    $total += $subtotal;

    echo "<p>{$product['name']} (x$qty) - $subtotal 
          <a href='remove_from_cart.php?id=$id'>[Remove]</a></p>";
}

echo "<hr><strong>Total: $total</strong>";
