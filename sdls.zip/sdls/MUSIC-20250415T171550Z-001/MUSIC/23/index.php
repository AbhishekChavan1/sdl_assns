<?php
session_start();
include 'db.php';

$result = $conn->query("SELECT * FROM products");
?>

<h2>Grocery Store</h2>
<a href="cart.php">View Cart</a>
<hr>

<?php while($row = $result->fetch_assoc()): ?>
    <p>
        <b><?= $row['name'] ?></b> - $<?= $row['price'] ?>
        <a href="add_to_cart.php?id=<?= $row['id'] ?>">[Add to Cart]</a>
    </p>
<?php endwhile; ?>
