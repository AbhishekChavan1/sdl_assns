<?php include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $course = $_POST['course_name'];
    $dept = $_POST['department'];

    $stmt = $pdo->prepare("INSERT INTO courses (course_name, department) VALUES (?, ?)");
    $stmt->execute([$course, $dept]);

    echo "Course added!";
}
?>

<h2>Add New Course</h2>
<form method="POST">
    Course Name: <input name="course_name" required><br><br>
    Department: <input name="department" required><br><br>
    <input type="submit" value="Add Course">
</form>
