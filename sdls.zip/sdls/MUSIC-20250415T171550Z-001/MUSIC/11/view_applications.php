<?php include 'db.php';

$apps = $pdo->query("SELECT s.*, c.course_name, c.department 
                     FROM students s 
                     JOIN courses c ON s.course_id = c.id 
                     ORDER BY application_date DESC")->fetchAll();
?>

<h2>Applications List</h2>
<table border="1">
    <tr>
        <th>ID</th><th>Name</th><th>Course</th><th>Status</th><th>Date</th><th>Action</th>
    </tr>
    <?php foreach ($apps as $app): ?>
        <tr>
            <td><?= $app['id'] ?></td>
            <td><?= $app['full_name'] ?></td>
            <td><?= $app['course_name'] ?> (<?= $app['department'] ?>)</td>
            <td><?= $app['admission_status'] ?></td>
            <td><?= $app['application_date'] ?></td>
            <td>
                <form action="update_status.php" method="POST">
                    <input type="hidden" name="id" value="<?= $app['id'] ?>">
                    <select name="status">
                        <option value="Pending" <?= $app['admission_status']=='Pending'?'selected':'' ?>>Pending</option>
                        <option value="Accepted" <?= $app['admission_status']=='Accepted'?'selected':'' ?>>Accepted</option>
                        <option value="Rejected" <?= $app['admission_status']=='Rejected'?'selected':'' ?>>Rejected</option>
                    </select>
                    <input type="submit" value="Update">
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
