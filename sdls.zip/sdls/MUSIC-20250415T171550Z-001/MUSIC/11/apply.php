<?php include 'db.php';

$courses = $pdo->query("SELECT * FROM courses")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $stmt = $pdo->prepare("INSERT INTO students (full_name, email, phone, dob, gender, address, course_id) 
                           VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $_POST['full_name'], $_POST['email'], $_POST['phone'],
        $_POST['dob'], $_POST['gender'], $_POST['address'], $_POST['course_id']
    ]);
    echo "Application submitted!";
}
?>

<h2>Student Admission Form</h2>
<form method="POST">
    Full Name: <input name="full_name" required><br><br>
    Email: <input type="email" name="email" required><br><br>
    Phone: <input name="phone"><br><br>
    Date of Birth: <input type="date" name="dob"><br><br>
    Gender:
    <select name="gender">
        <option>Male</option>
        <option>Female</option>
        <option>Other</option>
    </select><br><br>
    Address:<br>
    <textarea name="address"></textarea><br><br>
    Course:
    <select name="course_id">
        <?php foreach ($courses as $c): ?>
            <option value="<?= $c['id'] ?>"><?= $c['course_name'] ?> (<?= $c['department'] ?>)</option>
        <?php endforeach; ?>
    </select><br><br>
    <input type="submit" value="Apply Now">
</form>
