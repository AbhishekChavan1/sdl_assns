<?php
include 'auth.php';
include 'db.php';
check_login();

$id = $_GET['id'];
$conn->query("DELETE FROM items WHERE id=$id AND user_id = {$_SESSION['user_id']}");


header("Location: index.php");
exit();
?>
