<?php
include 'auth.php';
include 'db.php';
check_login();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Inventory Management</title>
</head>
<body>
    <p>Welcome, <?= $_SESSION['username'] ?> | <a href="logout.php">Logout</a></p>
    <h2>Inventory List</h2>
    <a href="create.php">Add New Item</a>
    <table border="1">
        <tr><th>ID</th><th>Name</th><th>Quantity</th><th>Actions</th></tr>
        <?php
        $user_id = $_SESSION['user_id'];
        $res = $conn->query("SELECT * FROM items WHERE user_id = $user_id");
        
        while ($row = $res->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['quantity']}</td>
                    <td>
                        <a href='edit.php?id={$row['id']}'>Edit</a> |
                        <a href='delete.php?id={$row['id']}'>Delete</a>
                    </td>
                  </tr>";
        }
        ?>
    </table>
</body>
</html>
