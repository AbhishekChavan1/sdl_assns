<?php
include 'auth.php';
include 'db.php';
check_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $qty = $_POST['quantity'];
    $user_id = $_SESSION['user_id'];
    $conn->query("INSERT INTO items (name, quantity, user_id) VALUES ('$name', '$qty', '$user_id')");
    header("Location: index.php");
    exit();
}
?>

<form method="POST">
    Name: <input name="name" required><br>
    Quantity: <input name="quantity" type="number" required><br>
    <button type="submit">Add Item</button>
</form>
