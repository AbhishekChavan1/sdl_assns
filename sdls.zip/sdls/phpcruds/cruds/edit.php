<?php
include 'auth.php';
include 'db.php';
check_login();

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $qty = $_POST['quantity'];
    $conn->query("UPDATE items SET name='$name', quantity='$qty' WHERE id=$id");
    header("Location: index.php");
    exit();
}

$res = $conn->query("SELECT * FROM items WHERE id=$id AND user_id = {$_SESSION['user_id']}");
$row = $res->fetch_assoc();
?>

<form method="POST">
    Name: <input name="name" value="<?= $row['name'] ?>" required><br>
    Quantity: <input name="quantity" type="number" value="<?= $row['quantity'] ?>" required><br>
    <button type="submit">Update</button>
</form>
