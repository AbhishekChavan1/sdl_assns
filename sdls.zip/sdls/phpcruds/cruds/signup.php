<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    // Check if the username is taken
    $res = $conn->query("SELECT * FROM users WHERE username = '$user'");
    if ($res->num_rows > 0) {
        $error = "Username already exists!";
    } else {
        $conn->query("INSERT INTO users (username, password) VALUES ('$user', '$pass')");
        $_SESSION['username'] = $user;
        $_SESSION['user_id'] = $conn->insert_id;  // get inserted user's ID
        header("Location: index.php");

        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
</head>
<body>
    <h2>Register New Account</h2>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <form method="POST">
        Username: <input type="text" name="username" required><br>
        Password: <input type="password" name="password" required><br>
        <button type="submit">Register</button>
    </form>
    <p>Already have an account? <a href="signin.php">Login here</a></p>
</body>
</html>
