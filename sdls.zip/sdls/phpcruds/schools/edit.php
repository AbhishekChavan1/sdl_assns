<?php
include 'session.php';
include 'config.php';

if (!isset($_GET['id'])) {
    echo "Invalid Request.";
    exit();
}

$id = intval($_GET['id']);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize inputs
    $name  = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $grade = $conn->real_escape_string($_POST['grade']);

    $sql = "UPDATE students SET name='$name', email='$email', grade='$grade' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Fetch student details to populate the form
$sql = "SELECT * FROM students WHERE id = $id";
$result = $conn->query($sql);
if ($result->num_rows != 1) {
    echo "Student not found.";
    exit();
}
$student = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Edit Student</h2>
    <form method="post" action="edit.php?id=<?= $id ?>">
        <label>Name:</label>
        <input type="text" name="name" value="<?= htmlspecialchars($student['name']) ?>" required><br>
        <label>Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($student['email']) ?>" required><br>
        <label>Grade:</label>
        <input type="text" name="grade" value="<?= htmlspecialchars($student['grade']) ?>" required><br>
        <input type="submit" value="Update Student">
    </form>
    <a href="index.php">Back to Student List</a>
</body>
</html>