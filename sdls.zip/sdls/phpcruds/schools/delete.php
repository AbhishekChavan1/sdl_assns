<?php
include 'session.php';
include 'config.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Ensure $id is an integer
    $sql = "DELETE FROM students WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "Invalid Request.";
}
?>
