<?php
include 'session.php';
include 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student List</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Welcome <?= $_SESSION['username'] ?> | <a href="logout.php">Logout</a></h2>
    <a href="add.php">Add Student</a>
    <table border="1">
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Grade</th><th>Actions</th></tr>
        <?php
        $result = $conn->query("SELECT * FROM students");
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['email']}</td>
                <td>{$row['grade']}</td>
                <td>
                    <a href='edit.php?id={$row['id']}'>Edit</a> |
                    <a href='delete.php?id={$row['id']}'>Delete</a>
                </td>
            </tr>";
        }
        ?>
    </table>
</body>
</html>
