<?php
include 'session.php';
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize inputs
    $name  = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $grade = $conn->real_escape_string($_POST['grade']);

    $sql = "INSERT INTO students (name, email, grade) VALUES ('$name', '$email', '$grade')";
    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Student</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Add Student</h2>
    <form method="post" action="add.php">
        <label>Name:</label>
        <input type="text" name="name" required><br>
        <label>Email:</label>
        <input type="email" name="email" required><br>
        <label>Grade:</label>
        <input type="text" name="grade" required><br>
        <input type="submit" value="Add Student">
    </form>
    <a href="index.php">Back to Student List</a>
</body>
</html>