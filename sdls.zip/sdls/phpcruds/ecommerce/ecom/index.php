<?php
session_start();

// Dummy user for login
$validUser = ["email" => "user@e.com", "password" => "1234"];

// Handle login
if (isset($_POST['login'])) {
    if ($_POST['email'] == $validUser['email'] && $_POST['password'] == $validUser['password']) {
        $_SESSION['user'] = $_POST['email'];
    } else {
        echo "<script>alert('Invalid credentials');</script>";
    }
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

// Handle add to cart
if (isset($_POST['add'])) {
    $item = $_POST['item'];
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    $_SESSION['cart'][] = $item;
}

// Handle remove from cart
if (isset($_POST['remove'])) {
    $index = $_POST['index'];
    unset($_SESSION['cart'][$index]);
    $_SESSION['cart'] = array_values($_SESSION['cart']);
}

$groceryItems = ["Rice", "Sugar", "Salt", "Oil", "Milk"];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Grocery E-Commerce</title>
</head>
<body>
    <h1>Grocery Store</h1>

    <?php if (!isset($_SESSION['user'])): ?>
        <!-- Login Form -->
        <form method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="login">Login</button>
        </form>
    <?php else: ?>
        <!-- User Greeting and Logout -->
        <p>Welcome, <?= $_SESSION['user'] ?> | <a href="?logout=1">Logout</a></p>

        <!-- Product List -->
        <h2>Products</h2>
        <form method="POST">
            <select name="item">
                <?php foreach ($groceryItems as $item): ?>
                    <option value="<?= $item ?>"><?= $item ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" name="add">Add to Cart</button>
        </form>

        <!-- Shopping Cart -->
        <h2>Cart</h2>
        <?php if (!empty($_SESSION['cart'])): ?>
            <ul>
                <?php foreach ($_SESSION['cart'] as $index => $item): ?>
                    <li>
                        <?= $item ?>
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="index" value="<?= $index ?>">
                            <button type="submit" name="remove">Remove</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>
